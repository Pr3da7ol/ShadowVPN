#!/usr/bin/env python3
"""
Shadow VPN Bot - Launcher con desencriptación
Desencripta y ejecuta main.py en memoria
"""

import sys
import tempfile
import shutil
import os
from pathlib import Path

KEY = b"ShadowVPN2026"

def xor_decrypt(data, key):
    return bytes([data[i] ^ key[i % len(key)] for i in range(len(data))])

def main():
    script_dir = Path(__file__).parent.resolve()
    
    # Crear directorio temporal
    temp_dir = Path(tempfile.mkdtemp(prefix="shadow_bot_secure_"))
    
    try:
        # Desencriptar archivos .enc
        enc_files = list(script_dir.glob("*.enc"))
        
        for enc_file in enc_files:
            with open(enc_file, "rb") as f:
                encrypted = f.read()
            
            decrypted = xor_decrypt(encrypted, KEY)
            py_name = enc_file.stem + ".py"
            
            with open(temp_dir / py_name, "wb") as f:
                f.write(decrypted)
        
        # Desencriptar cookies.json.enc local
        cookies_enc = script_dir / "cookies.json.enc"
        if cookies_enc.exists():
            with open(cookies_enc, "rb") as f:
                encrypted = f.read()
            decrypted = xor_decrypt(encrypted, KEY)
            with open(temp_dir / "cookies.json", "wb") as f:
                f.write(decrypted)
        
        # Copiar archivos no encriptados
        for item in ["README.md"]:
            src = script_dir / item
            if src.exists():
                shutil.copy2(src, temp_dir / item)
        
        # Copiar directorio libs/
        libs_src = script_dir / "libs"
        if libs_src.exists():
            shutil.copytree(libs_src, temp_dir / "libs")
        
        # Configurar variable de entorno para que vpn_core lea cookies del VPS
        home = Path.home()
        cookie_sources = [
            str(home / "VPS" / "ptah_vps" / "cookies.json"),
            str(home / "VPS" / "set_vps" / "cookies.json"),
            str(home / "VPS" / "anubis_vps" / "cookies.json"),
            str(temp_dir / "cookies.json")
        ]
        os.environ["SHADOW_COOKIE_SOURCES"] = ":".join(cookie_sources)
        
        # Cambiar al directorio temporal
        os.chdir(temp_dir)
        sys.path.insert(0, str(temp_dir))
        
        # Importar y ejecutar main
        import main
        
    except KeyboardInterrupt:
        print("\n[INFO] Detenido por usuario")
    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Limpiar directorio temporal
        try:
            shutil.rmtree(temp_dir)
        except:
            pass

if __name__ == "__main__":
    main()
