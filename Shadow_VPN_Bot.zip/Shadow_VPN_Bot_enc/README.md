# Shadow VPN Bot

Bot de descargas VPN con servidor completo integrado basado en Flask. 
Combina capacidades de DF_VPN + vpn_local_server_sdc.

## Características

- 🚀 Servidor web en puerto **8080**
- 🔐 Sistema de encriptación de URLs
- 📦 Descarga por chunks paralela
- 🌐 Soporte para Nextcloud y Moodle
- 🔄 Sistema de reintentos automático
- 📊 Interfaz web de estado
- 🎥 **Streaming de video/audio**
- 🔗 **Resolución de URLs cortas** (tinyurl, etc)
- 🍪 **Gestión automática de cookies**
- 💾 **Descarga directa desde Nextcloud/Moodle**

## Dioses Soportados

### Nextcloud
- **shiva** - cloud.udg.co.cu (ptah)
- **ares** - nube.uo.edu.cu (set)

### Moodle
- **fenix** - moodle.instec.cu (anubis)

## Instalación

El bot ya está configurado y listo para usar en:
```
/data/data/com.termux/files/home/Shadow_VPN_Bot/
```

## Uso

### Iniciar el bot
```bash
cd ~/Shadow_VPN_Bot
./start_shadow_bot.sh start
```

### Detener el bot
```bash
./start_shadow_bot.sh stop
```

### Ver estado
```bash
./start_shadow_bot.sh status
```

### Reiniciar
```bash
./start_shadow_bot.sh restart
```

## Endpoints

### Bot DF_VPN (Original)
- **http://localhost:8080/download** - Interfaz de descarga web
- **http://localhost:8080/api/download** - API de descarga

### VPN Core (Nuevas capacidades)
- **http://localhost:8080/status** - Estado del servidor
- **http://localhost:8080/cookies/status** - Estado de cookies
- **http://localhost:8080/cookies/refresh** - Refrescar cookies desde VPS
- **http://localhost:8080/resolve?url=...** - Resolver URL corta a enlace local
- **http://localhost:8080/stream/{token}** - Streaming de video
- **http://localhost:8080/watch/{token}** - Reproducción de video
- **http://localhost:8080/dl/{token}** - Descarga directa

### Ejemplos

#### Resolver tinyurl
```bash
curl "http://localhost:8080/resolve?url=https://tinyurl.com/abc123"
# Devuelve: http://localhost:8080/download/TOKEN?sig=SIGNATURE
```

#### Ver estado de cookies
```bash
curl http://localhost:8080/cookies/status | jq
```

#### Refrescar cookies
```bash
curl -X POST http://localhost:8080/cookies/refresh
```

## Configuración de Cookies

Las cookies se almacenan en `cookies.json`:

```json
{
  "shiva": "oc_sessionPassphrase=...",
  "ares": "oc_sessionPassphrase=...",
  "fenix": "MoodleSession=..."
}
```

## Logs

Ver logs en tiempo real:
```bash
tail -f ~/Shadow_VPN_Bot/shadow_bot.log
```

## Integración con Shadow_VPN

Shadow_VPN_Bot es un servidor completo que integra:
- **DF_VPN** - Bot de descargas por chunks
- **vpn_local_server_sdc** - Servidor VPN con resolución, streaming y cookies

Ambos trabajan en el puerto **8080** compartiendo cookies desde:
- `/data/data/com.termux/files/home/VPS/*/app.py`
- `/data/data/com.termux/files/home/Shadow_VPN_Bot/cookies.json`

## Arquitectura

```
Shadow_VPN_Bot (Puerto 8080)
├── Flask App (main.py)
│   ├── Rutas DF_VPN (flask_routes.py)
│   │   ├── /download (Web UI)
│   │   └── /api/download (API)
│   └── Rutas VPN Core (vpn_routes.py)
│       ├── /status, /health
│       ├── /cookies/status, /cookies/refresh
│       ├── /resolve?url=...
│       └── /stream, /watch, /dl
└── VPN Core (vpn_core.py)
    ├── Token encoding/decoding
    ├── Cookie management
    ├── Authentication (Nextcloud/Moodle)
    └── Streaming & Download
```

## Estructura

```
Shadow_VPN_Bot/
├── main.py                  # Servidor Flask principal
├── config.py               # Configuración (puerto 8080, dioses)
├── flask_routes.py         # Rutas DF_VPN (descarga web)
├── vpn_routes.py           # Rutas VPN Core (NEW)
├── vpn_core.py             # Servidor VPN completo (NEW)
├── download_manager.py     # Gestor de descargas
├── chunk_downloader.py     # Descarga por chunks
├── url_encryption.py       # Encriptación de URLs
├── utils.py                # Utilidades
├── cookies.json            # Cookies almacenadas
├── start_shadow_bot.sh     # Script de inicio
└── README.md              # Esta documentación
```

## Capacidades VPN Core

El módulo `vpn_core.py` (3151 líneas de vpn_local_server_sdc.py) proporciona:

- ✅ **Resolución de URLs** - Convierte tinyurl/shortlinks a enlaces descargables
- ✅ **Streaming adaptativo** - Video/audio con soporte de Range requests
- ✅ **Auto-login** - Autenticación automática en Nextcloud/Moodle
- ✅ **Cookie sync** - Sincronización desde perfiles VPS
- ✅ **Token management** - Tokens seguros con firma HMAC
- ✅ **Multi-platform** - Soporta Nextcloud, Moodle, OJS
- ✅ **Download/Upload** - Proxy completo de archivos
- ✅ **Transcodificación** - Conversión de video on-the-fly

## Notas

- Servidor completo **DF_VPN + VPN Core** integrados
- Solo 3 dioses configurados: **shiva, ares, fenix**
- Puerto **8080** fijo para compatibilidad
- Cookies compartidas con VPS profiles
- Sistema de logs limpio y minimalista
- Compatible con todas las funciones de vpn_local_server_sdc

## Versión

**Shadow VPN Bot v1.0** - Febrero 2026
- Base: DF_VPN-Down_v15.4.3pyBeta
- Core: vpn_local_server_sdc (3151 líneas)
- Integración completa Flask + HTTP Server
