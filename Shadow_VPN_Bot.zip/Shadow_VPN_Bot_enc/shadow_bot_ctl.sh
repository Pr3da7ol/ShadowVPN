#!/bin/bash
# Shadow VPN Bot Control Script

BOT_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$BOT_DIR/.shadow_bot.pid"
LOG_FILE="$BOT_DIR/shadow_bot.log"

cd "$BOT_DIR" || exit 1

start_bot() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if kill -0 "$PID" 2>/dev/null; then
            echo "[INFO] Bot ya está corriendo (PID: $PID)"
            return 1
        fi
        rm -f "$PID_FILE"
    fi
    
    nohup python3 run_shadow_bot.py > "$LOG_FILE" 2>&1 &
    echo $! > "$PID_FILE"
    sleep 2
    
    if kill -0 $(cat "$PID_FILE") 2>/dev/null; then
        echo "[OK] Shadow VPN Bot iniciado (PID: $(cat "$PID_FILE"))"
        echo "[INFO] Log: $LOG_FILE"
        return 0
    else
        echo "[ERROR] No se pudo iniciar el bot"
        rm -f "$PID_FILE"
        return 1
    fi
}

stop_bot() {
    if [ ! -f "$PID_FILE" ]; then
        echo "[INFO] Bot no está corriendo"
        return 0
    fi
    
    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        kill "$PID"
        sleep 2
        if kill -0 "$PID" 2>/dev/null; then
            kill -9 "$PID" 2>/dev/null
        fi
        echo "[OK] Bot detenido"
    fi
    rm -f "$PID_FILE"
}

status_bot() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if kill -0 "$PID" 2>/dev/null; then
            echo "[OK] Shadow VPN Bot activo (PID: $PID)"
            return 0
        else
            echo "[INFO] PID file existe pero proceso no corre"
            rm -f "$PID_FILE"
            return 1
        fi
    else
        echo "[INFO] Shadow VPN Bot inactivo"
        return 1
    fi
}

case "${1:-start}" in
    start)
        start_bot
        ;;
    stop)
        stop_bot
        ;;
    restart)
        stop_bot
        sleep 1
        start_bot
        ;;
    status)
        status_bot
        ;;
    logs)
        tail -f "$LOG_FILE"
        ;;
    *)
        echo "Uso: $0 {start|stop|restart|status|logs}"
        exit 1
        ;;
esac
