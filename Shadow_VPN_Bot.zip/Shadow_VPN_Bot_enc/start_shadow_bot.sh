#!/usr/bin/env bash
# start_shadow_bot.sh - Iniciador de Shadow VPN Bot

set -euo pipefail

BOT_DIR="/data/data/com.termux/files/home/Shadow_VPN_Bot"
PID_FILE="$BOT_DIR/.shadow_bot.pid"
LOG_FILE="$BOT_DIR/shadow_bot.log"

COLOR_GREEN='\033[0;32m'
COLOR_CYAN='\033[0;36m'
COLOR_RED='\033[0;31m'
COLOR_RESET='\033[0m'

print_header() {
  echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
  echo -e "${COLOR_CYAN}  Shadow VPN Bot${COLOR_RESET} ${COLOR_GREEN}v1.0${COLOR_RESET}"
  echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
  echo ""
}

start_bot() {
  if [[ -f "$PID_FILE" ]] && kill -0 $(cat "$PID_FILE") 2>/dev/null; then
    echo -e "${COLOR_GREEN}✓${COLOR_RESET} Bot ya está corriendo (PID: $(cat "$PID_FILE"))"
    echo ""
    echo -e "  ${COLOR_CYAN}http://localhost:8080/download${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}http://localhost:8080/status${COLOR_RESET}"
    return 0
  fi

  cd "$BOT_DIR"
  
  echo -e "${COLOR_GREEN}→${COLOR_RESET} Iniciando Shadow VPN Bot..."
  
  nohup python3 main.py > "$LOG_FILE" 2>&1 &
  echo $! > "$PID_FILE"
  
  sleep 2
  
  if kill -0 $(cat "$PID_FILE") 2>/dev/null; then
    echo -e "${COLOR_GREEN}✓${COLOR_RESET} Bot iniciado correctamente"
    echo ""
    echo -e "  Web: ${COLOR_CYAN}http://localhost:8080/download${COLOR_RESET}"
    echo -e "  Status: ${COLOR_CYAN}http://localhost:8080/status${COLOR_RESET}"
    echo ""
    echo -e "  Dioses disponibles: ${COLOR_GREEN}shiva, ares, fenix${COLOR_RESET}"
    echo ""
    echo -e "  Logs: tail -f $LOG_FILE"
  else
    echo -e "${COLOR_RED}✗${COLOR_RESET} Error al iniciar el bot"
    rm -f "$PID_FILE"
    return 1
  fi
}

stop_bot() {
  if [[ ! -f "$PID_FILE" ]]; then
    echo -e "${COLOR_RED}✗${COLOR_RESET} Bot no está corriendo"
    return 1
  fi
  
  PID=$(cat "$PID_FILE")
  
  if kill -0 "$PID" 2>/dev/null; then
    echo -e "${COLOR_GREEN}→${COLOR_RESET} Deteniendo bot (PID: $PID)..."
    kill "$PID"
    sleep 1
    
    if kill -0 "$PID" 2>/dev/null; then
      kill -9 "$PID" 2>/dev/null
    fi
    
    echo -e "${COLOR_GREEN}✓${COLOR_RESET} Bot detenido"
  fi
  
  rm -f "$PID_FILE"
}

status_bot() {
  if [[ -f "$PID_FILE" ]] && kill -0 $(cat "$PID_FILE") 2>/dev/null; then
    PID=$(cat "$PID_FILE")
    echo -e "${COLOR_GREEN}✓${COLOR_RESET} Bot activo (PID: $PID)"
    echo ""
    echo -e "  ${COLOR_CYAN}http://localhost:8080/download${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}http://localhost:8080/status${COLOR_RESET}"
    return 0
  else
    echo -e "${COLOR_RED}✗${COLOR_RESET} Bot inactivo"
    return 1
  fi
}

case "${1:-start}" in
  start)
    print_header
    start_bot
    ;;
  stop)
    print_header
    stop_bot
    ;;
  restart)
    print_header
    stop_bot
    sleep 1
    start_bot
    ;;
  status)
    print_header
    status_bot
    ;;
  *)
    echo "Uso: $0 {start|stop|restart|status}"
    exit 1
    ;;
esac
