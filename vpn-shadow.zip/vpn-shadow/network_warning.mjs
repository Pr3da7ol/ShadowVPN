const STATUS_EVENT = 'shadowvpn:status';
const MOUNT_SELECTOR = '[data-network-warning]';
const STYLE_ID = 'shadowvpn-network-warning-style';

function mounts() {
  return Array.from(document.querySelectorAll(MOUNT_SELECTOR));
}

function ensureStyles() {
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.textContent = `
    [data-network-warning] {
      position: fixed;
      top: 12px;
      left: 50%;
      transform: translateX(-50%);
      width: min(920px, calc(100vw - 24px));
      z-index: 9998;
      pointer-events: none;
    }
    .shadowvpn-netwarn-card {
      pointer-events: auto;
      display: grid;
      gap: 8px;
      padding: 14px 16px;
      border-radius: 16px;
      border: 1px solid rgba(235, 189, 77, 0.34);
      background:
        linear-gradient(135deg, rgba(14, 18, 24, 0.97), rgba(27, 20, 8, 0.96)),
        radial-gradient(circle at top left, rgba(235, 189, 77, 0.12), transparent 55%);
      box-shadow: 0 18px 46px rgba(0, 0, 0, 0.34);
      color: #f6e7bc;
      font: 14px/1.45 ui-monospace, 'SFMono-Regular', Consolas, monospace;
      backdrop-filter: blur(10px);
    }
    .shadowvpn-netwarn-head {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 10px;
    }
    .shadowvpn-netwarn-badge {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 84px;
      padding: 4px 10px;
      border-radius: 999px;
      border: 1px solid rgba(235, 189, 77, 0.4);
      background: rgba(235, 189, 77, 0.1);
      color: #ffdd7a;
      font-size: 12px;
      letter-spacing: 0.14em;
      text-transform: uppercase;
    }
    .shadowvpn-netwarn-title {
      color: #fff2c8;
      font-size: 15px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
    }
    .shadowvpn-netwarn-meta,
    .shadowvpn-netwarn-foot,
    .shadowvpn-netwarn-action {
      color: rgba(255, 239, 193, 0.82);
      font-size: 12px;
    }
    .shadowvpn-netwarn-message {
      color: #fff2c8;
      font-size: 13px;
    }
    .shadowvpn-netwarn-action {
      color: #ffd97a;
    }
    @media (max-width: 640px) {
      [data-network-warning] {
        top: 10px;
        width: calc(100vw - 16px);
      }
      .shadowvpn-netwarn-card {
        padding: 12px 13px;
      }
    }
  `;
  document.head.appendChild(style);
}

function clearMount(mount) {
  if (!mount) return;
  mount.hidden = true;
  mount.replaceChildren();
}

function line(className, text) {
  const node = document.createElement('div');
  node.className = className;
  node.textContent = String(text || '').trim();
  return node;
}

function render(status) {
  const warning = status && typeof status === 'object' ? status.network_warning || {} : {};
  const show = !!warning.show;
  const slots = mounts();
  if (!slots.length) return;
  ensureStyles();

  if (!show) {
    slots.forEach(clearMount);
    return;
  }

  const ip = String(warning.ip || 'n/d');
  const iface = String(warning.interface || '').trim();
  const range = String(warning.range_text || '10.20 - 10.90');
  const title = String(warning.title || 'Advertencia de red');
  const message = String(
    warning.message ||
      'La IP detectada está fuera del rango sugerido. En algunas redes esto podria consumir megas.'
  );
  const detail = String(
    warning.detail || 'Es una advertencia preventiva; no es una confirmacion de consumo.'
  );
  const meta = `IP detectada: ${ip}${iface ? ` · ${iface}` : ''} · rango sugerido: ${range}`;
  const action = 'Sugerencia: activa modo avion 10-15 s, reconecta y vuelve a probar si quieres otra IP.';

  slots.forEach((mount) => {
    mount.hidden = false;
    mount.replaceChildren();

    const card = document.createElement('section');
    card.className = 'shadowvpn-netwarn-card';

    const head = document.createElement('div');
    head.className = 'shadowvpn-netwarn-head';
    head.append(line('shadowvpn-netwarn-badge', 'NET-WARN'), line('shadowvpn-netwarn-title', title));

    card.append(
      head,
      line('shadowvpn-netwarn-meta', meta),
      line('shadowvpn-netwarn-message', message),
      line('shadowvpn-netwarn-foot', detail),
      line('shadowvpn-netwarn-action', action)
    );

    mount.appendChild(card);
  });
}

function refreshFromApi() {
  fetch('/api/status', { cache: 'no-store' })
    .then((response) => response.text())
    .then((text) => {
      try {
        return JSON.parse(text);
      } catch (_) {
        return {};
      }
    })
    .then((data) => render(data || {}))
    .catch(() => {});
}

window.addEventListener(STATUS_EVENT, (event) => {
  render((event && event.detail) || {});
});

ensureStyles();
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', refreshFromApi, { once: true });
} else {
  refreshFromApi();
}
