# Shadow VPN (Modular)

Base: `vpn_local_server_sdc.py`

## Estructura

- `shadow_vpn.py`: entrada principal.
- `parts/`: SDC dividido en 5 partes por responsabilidades.
- `loader.py`: recompone el runtime original en un namespace compartido.
- `shadow_bridge.py`: mejoras de compatibilidad para enlaces Moodle y rangos.
- `styles.css`: estilos generados desde SDC.
- `downloader.html`: interfaz de descargas generada desde SDC.
- `downloader.txt`: plantilla/cola para importacion de descargas.

## Ejecutar

```bash
python vpn-shadow/shadow_vpn.py --host 127.0.0.1 --port 8080
```
