#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_HOST="${SHADOW_VPN_HOST:-127.0.0.1}"
DEFAULT_PORT="${SHADOW_VPN_PORT:-8080}"
DEFAULT_INTERVAL="${SHADOW_VPN_INTERVAL:-30}"
DEFAULT_VPS_ROOT="${SHADOW_VPN_VPS_ROOT:-/data/data/com.termux/files/home/VPS}"
DEFAULT_SERVER_PATH="${SHADOW_SERVER_PATH:-$BASE_DIR/vpn_core.py}"
START_TIMEOUT="${SHADOW_VPN_START_TIMEOUT:-20}"
LAUNCH_SCRIPT_DEFAULT="$BASE_DIR/shadow_vpn.py"
if [[ -f "$BASE_DIR/run_shadow_secure.py" ]]; then
  LAUNCH_SCRIPT_DEFAULT="$BASE_DIR/run_shadow_secure.py"
fi
LAUNCH_SCRIPT="${SHADOW_VPN_LAUNCH_SCRIPT:-$LAUNCH_SCRIPT_DEFAULT}"

resolve_python_bin() {
  if [[ -n "${PYTHON_BIN:-}" ]]; then
    echo "$PYTHON_BIN"
    return
  fi
  if [[ -x "/data/data/com.termux/files/usr/bin/python3" ]]; then
    echo "/data/data/com.termux/files/usr/bin/python3"
    return
  fi
  command -v python3
}
PY="$(resolve_python_bin)"
PID_FILE="$BASE_DIR/shadow_vpn.pid"
LOG_FILE="$BASE_DIR/shadow_vpn.log"
ARGS_FILE="$BASE_DIR/shadow_vpn.args"

effective_args() {
  if [[ "$#" -gt 0 ]]; then
    printf '%s\n' "$@"
    return
  fi
  printf '%s\n' \
    "--host" "$DEFAULT_HOST" \
    "--port" "$DEFAULT_PORT" \
    "--interval" "$DEFAULT_INTERVAL" \
    "--vps-root" "$DEFAULT_VPS_ROOT" \
    "--server-path" "$DEFAULT_SERVER_PATH"
}

extract_host_port() {
  local host="$DEFAULT_HOST"
  local port="$DEFAULT_PORT"
  local args=("$@")
  local i=0
  while [[ $i -lt ${#args[@]} ]]; do
    case "${args[$i]}" in
      --host)
        if [[ $((i + 1)) -lt ${#args[@]} ]]; then
          host="${args[$((i + 1))]}"
          i=$((i + 1))
        fi
        ;;
      --port)
        if [[ $((i + 1)) -lt ${#args[@]} ]]; then
          port="${args[$((i + 1))]}"
          i=$((i + 1))
        fi
        ;;
    esac
    i=$((i + 1))
  done
  printf '%s %s\n' "$host" "$port"
}

wait_http_ready() {
  local host="$1"
  local port="$2"
  local pid="$3"
  local deadline=$((SECONDS + START_TIMEOUT))

  if ! command -v curl >/dev/null 2>&1; then
    return 0
  fi

  while (( SECONDS < deadline )); do
    if ! kill -0 "$pid" 2>/dev/null; then
      return 1
    fi
    if curl -fsS --max-time 2 "http://${host}:${port}/" >/dev/null 2>&1; then
      return 0
    fi
    sleep 1
  done
  return 1
}

start_vpn() {
  if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    echo "[INFO] Shadow_VPN ya está corriendo (pid=$(cat "$PID_FILE"))."
    exit 0
  fi
  mapfile -t run_args < <(effective_args "$@")
  read -r host port < <(extract_host_port "${run_args[@]}")

  echo "[INFO] Iniciando Shadow_VPN..."
  {
    echo "[BOOT] $(date '+%Y-%m-%d %H:%M:%S') start args: ${run_args[*]}"
    echo "[BOOT] python: $PY"
  } >>"$LOG_FILE"
  nohup "$PY" -u "$LAUNCH_SCRIPT" "${run_args[@]}" >>"$LOG_FILE" 2>&1 &
  echo $! >"$PID_FILE"
  printf '%s\n' "${run_args[@]}" >"$ARGS_FILE"

  if wait_http_ready "$host" "$port" "$(cat "$PID_FILE")"; then
    echo "[OK] Shadow_VPN iniciado (pid=$(cat "$PID_FILE")) en http://$host:$port"
    echo "[INFO] Log: $LOG_FILE"
  else
    echo "[ERROR] No se pudo iniciar Shadow_VPN. Revisa $LOG_FILE"
    {
      echo "[BOOT] $(date '+%Y-%m-%d %H:%M:%S') proceso finalizó durante start"
    } >>"$LOG_FILE"
    rm -f "$PID_FILE"
    exit 1
  fi
}

stop_vpn() {
  if [[ ! -f "$PID_FILE" ]]; then
    echo "[INFO] Shadow_VPN no está corriendo (sin pid file)."
    exit 0
  fi
  pid="$(cat "$PID_FILE")"
  if kill -0 "$pid" 2>/dev/null; then
    echo "[INFO] Deteniendo Shadow_VPN (pid=$pid)..."
    kill "$pid" || true
    sleep 1
    if kill -0 "$pid" 2>/dev/null; then
      kill -9 "$pid" || true
    fi
  fi
  rm -f "$PID_FILE"
  rm -f "$ARGS_FILE"
  echo "[OK] Shadow_VPN detenido."
}

status_vpn() {
  if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    local host="$DEFAULT_HOST"
    local port="$DEFAULT_PORT"
    if [[ -f "$ARGS_FILE" ]]; then
      mapfile -t a <"$ARGS_FILE"
      read -r host port < <(extract_host_port "${a[@]}")
    fi
    if command -v curl >/dev/null 2>&1 && curl -fsS --max-time 2 "http://${host}:${port}/" >/dev/null 2>&1; then
      echo "[OK] Shadow_VPN activo (pid=$(cat "$PID_FILE")) en http://$host:$port"
    else
      echo "[WARN] Shadow_VPN activo por PID pero sin respuesta HTTP en http://$host:$port"
    fi
    exit 0
  fi
  echo "[INFO] Shadow_VPN inactivo."
  exit 1
}

logs_vpn() {
  tail -n 120 -f "$LOG_FILE"
}

cmd="${1:-start}"
if [[ "${cmd:0:1}" == "-" ]]; then
  cmd="start"
else
  shift || true
fi

case "$cmd" in
  start) start_vpn "$@" ;;
  stop) stop_vpn ;;
  restart) stop_vpn || true; start_vpn "$@" ;;
  status) status_vpn ;;
  logs) logs_vpn ;;
  *)
    echo "Uso: $0 {start|stop|restart|status|logs}"
    echo "Ejemplo: $0 start --host 127.0.0.1 --port 8080 --interval 30"
    exit 1
    ;;
esac
