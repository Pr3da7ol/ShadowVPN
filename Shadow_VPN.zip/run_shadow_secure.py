#!/usr/bin/env python3
from __future__ import annotations

import base64
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path

DEFAULT_KEY = "shadow_vpn_secure_key_2026"


def _key_stream(secret: bytes, salt: bytes, length: int) -> bytes:
    blocks = []
    counter = 0
    total = 0
    while total < length:
        counter_bytes = counter.to_bytes(8, "big", signed=False)
        block = hashlib.sha256(secret + salt + counter_bytes).digest()
        blocks.append(block)
        total += len(block)
        counter += 1
    return b"".join(blocks)[:length]


def _decrypt_payload(path: Path, key: str) -> bytes:
    payload = json.loads(path.read_text(encoding="utf-8"))
    salt = base64.urlsafe_b64decode(str(payload["salt"]).encode("ascii"))
    cipher = base64.urlsafe_b64decode(str(payload["ct"]).encode("ascii"))
    stream = _key_stream(key.encode("utf-8"), salt, len(cipher))
    return bytes(c ^ s for c, s in zip(cipher, stream))


def _filtered_forward_args(args: list[str]) -> list[str]:
    out: list[str] = []
    skip_next = False
    for i, arg in enumerate(args):
        if skip_next:
            skip_next = False
            continue
        if arg in ("--server-path", "--sync-script-path"):
            if i + 1 < len(args):
                skip_next = True
            continue
        out.append(arg)
    return out


def main() -> int:
    base_dir = Path(__file__).resolve().parent
    secure_dir = base_dir / "secure"

    shadow_enc = secure_dir / "shadow_vpn.py.enc"
    core_enc = secure_dir / "vpn_core.py.enc"
    sync_enc = secure_dir / "sync_shadow_cookies.py.enc"

    if not shadow_enc.exists() or not core_enc.exists() or not sync_enc.exists():
        print("[ERROR] Payload seguro incompleto.")
        return 1

    key = os.getenv("SHADOW_PAYLOAD_KEY", DEFAULT_KEY)
    runtime_dir = Path(tempfile.mkdtemp(prefix="shadow_vpn_secure_"))

    try:
        shadow_py = runtime_dir / "shadow_vpn.py"
        core_py = runtime_dir / "vpn_core.py"
        sync_py = runtime_dir / "sync_shadow_cookies.py"

        shadow_py.write_bytes(_decrypt_payload(shadow_enc, key))
        core_py.write_bytes(_decrypt_payload(core_enc, key))
        sync_py.write_bytes(_decrypt_payload(sync_enc, key))

        forward_args = _filtered_forward_args(sys.argv[1:])
        argv = [
            sys.executable,
            str(shadow_py),
            *forward_args,
            "--server-path",
            str(core_py),
            "--sync-script-path",
            str(sync_py),
        ]
        os.execv(sys.executable, argv)
    except Exception as exc:
        print(f"[ERROR] No se pudo iniciar payload seguro: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
