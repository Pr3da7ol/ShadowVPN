# Shadow_VPN

VPN local completa basada en `vpn_local_server_sdc.py`, con sincronización automática de cookies desde tus `_vps` (`VPS/*_vps/app.py`) cada 30 segundos.

## Componentes

- `shadow_vpn.py`: launcher principal (localhost + sincronizador de cookies)
- `sync_shadow_cookies.py`: consolida cookies/credenciales de `_vps` en `cookies.json`
- `shadow_vpn_ctl.sh`: control de servicio (`start|stop|restart|status|logs`), sin argumentos inicia (`start`)
- `start_vpn.bash`: lanzador amigable (limpieza + ofuscación + inicio)

## Uso rápido

```bash
cd /data/data/com.termux/files/home/VPS/Shadow_VPN
./shadow_vpn_ctl.sh
```

Arranque directo desde `~`:

```bash
cd /data/data/com.termux/files/home
./start_vpn.bash
```

Ver estado:

```bash
./shadow_vpn_ctl.sh status
```

Ver logs:

```bash
./shadow_vpn_ctl.sh logs
```

Detener:

```bash
./shadow_vpn_ctl.sh stop
```

## Notas

- El ZIP de distribución (`Shadow_VPN.zip`) incluye el runtime Python cifrado (`secure/*.enc`).
- Se genera `cookies.json` consolidado en esta carpeta.
- Se usa `cookies_runtime.json` como store runtime para el servidor local.
- Alias de compatibilidad: si existe perfil `ptah`, se crea también `set` automáticamente.
- Puerto por defecto: `8080` (compatible con tus enlaces `localhost:8080`).
- Si tienes conflicto de puerto, inicia con `./shadow_vpn_ctl.sh start --port 18080`.
- El endpoint `http://127.0.0.1:8080/cookies/refresh` se invoca en cada ciclo de sync.
