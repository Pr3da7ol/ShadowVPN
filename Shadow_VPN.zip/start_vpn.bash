#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VPS_ROOT="${SHADOW_VPN_VPS_ROOT:-/data/data/com.termux/files/home/VPS}"
LOCAL_SERVER_SRC="$BASE_DIR/vpn_core.py"
LOCAL_SERVER_ENC="$BASE_DIR/vpn_core_enc.py"
LOCAL_SERVER_OBF="$BASE_DIR/vpn_core_enc_enc.py"
SHADOW_ENCODER="$BASE_DIR/shadow_encoder.py"
OBFUSCATOR="$BASE_DIR/obfuscator.py"

DOWNLOADS_DIR="/storage/emulated/0/Download/Shadow_VPN"
TMP_DIR="$DOWNLOADS_DIR/temporales"
RUNTIME_LOG="$DOWNLOADS_DIR/shadow_vpn.log"

COLOR_RED='\033[0;31m'
COLOR_GREEN='\033[0;32m'
COLOR_YELLOW='\033[0;33m'
COLOR_RESET='\033[0m'

print_msg() {
  local level="$1"
  local color="$2"
  local text="$3"
  echo -e "${color}[${level}] ${text}${COLOR_RESET}"
}

resolve_python_bin() {
  if [[ -n "${PYTHON_BIN:-}" ]]; then
    echo "$PYTHON_BIN"
    return
  fi
  if [[ -x "/data/data/com.termux/files/usr/bin/python3" ]]; then
    echo "/data/data/com.termux/files/usr/bin/python3"
    return
  fi
  command -v python3
}

cleanup_temporales() {
  mkdir -p "$TMP_DIR"
  find "$TMP_DIR" -mindepth 1 -maxdepth 1 -type f -delete 2>/dev/null || true
}

setup_runtime_dirs() {
  mkdir -p "$DOWNLOADS_DIR" "$TMP_DIR"
  touch "$RUNTIME_LOG" || true
}

ensure_obfuscated_server() {
  local py="$1"

  if [[ "${SHADOW_AUTO_OBFUSCATE:-1}" != "1" ]]; then
    print_msg "INFO" "$COLOR_YELLOW" "Ofuscacion desactivada (SHADOW_AUTO_OBFUSCATE=0)."
    export SHADOW_SERVER_PATH="$LOCAL_SERVER_SRC"
    return
  fi

  if [[ ! -f "$LOCAL_SERVER_SRC" || ! -f "$SHADOW_ENCODER" || ! -f "$OBFUSCATOR" ]]; then
    print_msg "WARN" "$COLOR_YELLOW" "No se encontraron herramientas de ofuscacion. Se usara payload normal."
    export SHADOW_SERVER_PATH="$LOCAL_SERVER_SRC"
    return
  fi

  local rebuild=0
  if [[ ! -f "$LOCAL_SERVER_OBF" ]]; then
    rebuild=1
  elif [[ "$LOCAL_SERVER_SRC" -nt "$LOCAL_SERVER_OBF" ]]; then
    rebuild=1
  elif [[ "$SHADOW_ENCODER" -nt "$LOCAL_SERVER_OBF" || "$OBFUSCATOR" -nt "$LOCAL_SERVER_OBF" ]]; then
    rebuild=1
  fi

  if [[ "$rebuild" -eq 1 ]]; then
    print_msg "INFO" "$COLOR_YELLOW" "Ofuscando nucleo de Shadow_VPN ..."
    printf '%s\n%s\n' "$LOCAL_SERVER_SRC" "$LOCAL_SERVER_ENC" | \
      "$py" "$SHADOW_ENCODER" -c "${SHADOW_LAYERS:-3}" --iterations "${SHADOW_ITERATIONS:-600000}" >/dev/null
    printf '%s\n%s\n' "$LOCAL_SERVER_ENC" "$LOCAL_SERVER_OBF" | \
      "$py" "$OBFUSCATOR" -c "${OBF_LAYERS:-4}" >/dev/null
    print_msg "OK" "$COLOR_GREEN" "Nucleo ofuscado listo: $LOCAL_SERVER_OBF"
  else
    print_msg "INFO" "$COLOR_YELLOW" "Nucleo ofuscado ya actualizado."
  fi

  export SHADOW_SERVER_PATH="$LOCAL_SERVER_OBF"
}

prepare_runtime_mode() {
  local py="$1"
  if [[ -f "$BASE_DIR/run_shadow_secure.py" && -f "$BASE_DIR/secure/shadow_vpn.py.enc" && -f "$BASE_DIR/secure/vpn_core.py.enc" && -f "$BASE_DIR/secure/sync_shadow_cookies.py.enc" ]]; then
    print_msg "INFO" "$COLOR_YELLOW" "Modo seguro activo (archivos .enc)."
    export SHADOW_VPN_LAUNCH_SCRIPT="$BASE_DIR/run_shadow_secure.py"
    unset SHADOW_SERVER_PATH || true
    return
  fi
  ensure_obfuscated_server "$py"
}

main() {
  local py
  py="$(resolve_python_bin)"

  setup_runtime_dirs

  # Guardar salida de este arranque tambien en log portable
  exec > >(tee -a "$RUNTIME_LOG") 2>&1

  print_msg "EXITO" "$COLOR_GREEN" "Shadow_VPN activado!"

  echo "Iniciando limpieza de archivos temporales..."
  cleanup_temporales

  export SHADOW_VPN_HOST="127.0.0.1"
  export SHADOW_VPN_PORT="8080"
  export SHADOW_VPN_INTERVAL="30"
  export SHADOW_VPN_VPS_ROOT="$VPS_ROOT"

  prepare_runtime_mode "$py"

  "$BASE_DIR/shadow_vpn_ctl.sh"

  echo "Shadow_VPN Server iniciado en puerto 8080"
  echo "Carpetas configuradas:"
  echo "  - Descargas: $DOWNLOADS_DIR"
  echo "  - Temporales: $TMP_DIR"
  echo "  - Logs: $RUNTIME_LOG"
  echo "Interfaz web disponible en: http://localhost:8080/"
  echo "Estado del sistema: http://localhost:8080/status"
  echo "Estado de cookies: http://localhost:8080/cookies/status"
}

main "$@"
